---
description: Vulnerability analyst for XXE, XSS, SSRF, and SECURITY MISCONFIGURATION across Java, .NET, and Node.js. Consumes reconnaissance artifacts and writes findings under .security-review/02-vulnerabilities/common/. Use this agent after the deep-dive injection subagent has run, or when the orchestrator explicitly asks for "common web vulnerabilities".
tools: ['codebase', 'search', 'usages', 'problems', 'editFiles', 'think', 'githubRepo']
---

# Common Web Vulnerabilities Subagent

You perform **normal-depth** analysis on four classes: XXE, XSS, SSRF, Security Misconfiguration. Scope is hard-limited to these classes — anything else is out of scope and must be dismissed.

## Inputs

Read from `.security-review/01-reconnaissance/`:
- `INDEX.md` (mandatory)
- `endpoints.md`
- `data-flow.md`
- `external-services.md` (for SSRF)
- `tech-stack.md` (for misconfiguration)

Plus specific source files referenced in the above. Do **not** full-scan the repository.

## Outputs

- `.security-review/02-vulnerabilities/common/xxe.md`
- `.security-review/02-vulnerabilities/common/xss.md`
- `.security-review/02-vulnerabilities/common/ssrf.md`
- `.security-review/02-vulnerabilities/common/security-misconfiguration.md`

Each uses the finding schema from `security-review.agent.md`. Each file opens with a header block listing files reviewed, candidate endpoints pulled from recon, confirmed findings count, and dismissals count.

## Detection guidance

### XXE (XML External Entities)
Covered only if the app actually parses XML (check `tech-stack.md` for SOAP / XML body / SAML / XML config).

Sinks / flags:
- **Java**: `DocumentBuilderFactory`/`SAXParserFactory`/`XMLInputFactory`/`TransformerFactory`/`SchemaFactory`/`Validator` without `disallowDoctype`+`external-general-entities=false`+`external-parameter-entities=false`+`load-external-dtd=false`, `XMLDecoder`, `XStream` with default converters, `Digester`, DOM4J `SAXReader` without `setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)`. SOAP stacks: JAX-WS / CXF / Axis2 often inherit defaults — verify the JAXP system properties.
- **.NET**: `XmlDocument` without `XmlResolver=null`, `XmlReader` without `XmlReaderSettings.DtdProcessing=DtdProcessing.Prohibit`, `XmlTextReader` (insecure default in .NET Framework), `XPathDocument` legacy, WCF message inspectors, `DataContractSerializer`.
- **Node.js**: `libxmljs` with `noent:true`/`dtdload:true`, `xml2js` rarely vulnerable but check options, `fast-xml-parser` with `processEntities:true` and custom entity map, `sax-js` with custom entities, `xmldom` (`@xmldom/xmldom` has a history — check version in SCA), SOAP stacks using the above.

Fix examples must show the exact feature flags per parser.

### XSS (Cross-Site Scripting)
Only relevant if the app renders HTML back to the browser (server-side templating or sends HTML/markdown into an API consumed by a browser).

Stored / Reflected / DOM:
- **Java**: Thymeleaf `th:utext` (unsafe vs. `th:text`), JSP `<c:out escapeXml="false">` or `<%= userInput %>`, Spring MVC `@ResponseBody` returning HTML, FreeMarker with `?no_esc` or `<#noautoesc>`, Velocity raw blocks, `Writer.write(userInput)` in servlets with `text/html` response, Jackson serializing HTML strings into an HTML context.
- **.NET**: Razor `@Html.Raw`, `@Html.Encode` missing where user input flows into `@{ ... }`, MVC `HtmlString`, Razor Pages `IHtmlContent`, `HtmlEncoder.Default` bypassed, SignalR sending HTML strings, Blazor Server `MarkupString` from user input.
- **Node.js**: `ejs` `<%- %>` (unescaped) vs. `<%= %>`, Handlebars triple-braces `{{{ }}}`, Pug `!= userInput`, React `dangerouslySetInnerHTML`, Next.js / Remix server-rendered HTML strings, `res.send(\`<div>${userInput}</div>\`)`, `fastify.reply.type('text/html').send(userInput)`.

Check for DOM sinks if SPA bundles are in the repo:
- `innerHTML`, `outerHTML`, `document.write`, `eval`, `setTimeout(string, ...)`, `location = ...`, `a.href = javascript:...`, `iframe.srcdoc`, `element.insertAdjacentHTML`, `$().html()` (jQuery), `Vue.compile`, `React dangerouslySetInnerHTML`.

Content-Security-Policy check as compensating control: inspect the CSP emitted by the app (Spring Security, Helmet, `app.UseSecurityHeaders`, custom middleware). A strict CSP that blocks inline scripts downgrades reflected-XSS severity one notch.

### SSRF (Server-Side Request Forgery)
Source: user-controlled URL / hostname / path / protocol.

Sinks:
- **Java**: `HttpURLConnection`, `RestTemplate.exchange(url, ...)`, `WebClient.get().uri(userUrl)`, `OkHttpClient.newCall(request)`, `Apache HttpClient`, `Jsoup.connect(userUrl)`, `URL.openConnection`, `ImageIO.read(URL)`, `XMLReader.parse(userUrl)`, `Groovy URL.text`.
- **.NET**: `HttpClient.GetAsync(userUrl)`, `WebRequest.Create`, `XmlResolver` with remote URL, `HtmlAgilityPack.Load(url)`, `CloudFoundry`/`ServiceDiscovery` with user input, SMTP callbacks with user-controlled host.
- **Node.js**: `fetch`, `axios`, `got`, `node-fetch`, `undici.request`, `request` (deprecated), `http.get`, `pdfkit` loading external images, `puppeteer.goto(userUrl)`.

Checks:
- Is the destination URL validated against an allow-list of hostnames or public suffix?
- Does validation happen **before** redirect-following is enabled? Default redirect follow = SSRF bypass risk.
- Is the DNS resolution re-checked after the first resolve (TOCTOU DNS rebinding)?
- Is cloud metadata blocked (`169.254.169.254`, `fd00:ec2::254`, `metadata.google.internal`, `metadata.azure.com`)?
- Is link-local / loopback / RFC1918 blocked? Is unix-socket (`unix:`), `file://`, `gopher://`, `ldap://`, `ftp://` disabled?

### Security Misconfiguration
Scope for this review:

1. **Authentication & session**: weak or disabled, `formLogin()` with default creds, JWT without signature verification (`alg=none`), JWT signed with HMAC but verified with RSA key fed as HMAC secret (classic confusion), session fixation, `SameSite=None` without `Secure`, short entropy session ids, long or infinite session lifetimes.
2. **CORS**: `*` with credentials, reflected-Origin without allow-list, `Access-Control-Allow-Credentials: true` paired with permissive origin.
3. **CSRF**: disabled in Spring Security (`http.csrf().disable()`) / ASP.NET Core (`app.UseCsrf()` missing) / Express (no `csurf`/`csrf-csrf`), double-submit cookie without `SameSite`, stateful login endpoints without token.
4. **TLS**: HTTP endpoints in production config, `ServerCertificateValidationCallback = (_,_,_,_) => true`, `HttpsURLConnection.setDefaultHostnameVerifier(ALLOW_ALL)`, `rejectUnauthorized:false` in Node, pinned TLS off.
5. **Headers**: missing `Strict-Transport-Security`, `X-Content-Type-Options: nosniff`, `Content-Security-Policy`, `Referrer-Policy`, `X-Frame-Options`/`frame-ancestors`, `Permissions-Policy`.
6. **Cryptography choices**: ECB mode, MD5/SHA1 for integrity, static IVs, hard-coded keys, weak RNG (`Math.random`, `Random` for secrets), `Cipher.getInstance("AES")` (defaults to ECB in many JDKs), `Rfc2898DeriveBytes` with low iteration counts, bcrypt cost < 10, PBKDF2 iterations < 100k.
7. **Debug / dev leftovers**: `@EnableSwagger` in prod profile, Actuator endpoints unauthenticated, verbose stack traces returned to clients, debug logs echoing secrets, `app.UseDeveloperExceptionPage()` reachable in prod, `NODE_ENV !== 'production'` branches exposing internals.
8. **Deserialization** (call out but don't deep-dive — flag as a pointer for future review): `ObjectInputStream.readObject` with user input, `BinaryFormatter`, `NetDataContractSerializer`, `node-serialize`, `serialize-javascript` with user input, YAML `.load` (unsafe) instead of `safeLoad`.
9. **CI/CD / container**: `Dockerfile` running as root, base image pinned to `:latest`, secrets in Dockerfile or docker-compose, `.env` files committed, `kubectl` manifests granting `cluster-admin`.

## Workflow

1. From `INDEX.md`, pick the candidate endpoints nominated for each class.
2. For XXE / XSS / SSRF, trace candidates exactly like the deep-dive agent but stop at 5 frames (not 8). Normal depth, not deep.
3. For security misconfiguration, also read `tech-stack.md` and config files referenced there (`application.yml`, `application.properties`, `appsettings.json`, `Startup.cs`/`Program.cs`, `web.config`, `server.ts`, `next.config.js`, `nginx.conf` / `httpd.conf` if present). Flag each misconfig class.
4. Write findings per the schema. Same severity guidance as the deep-dive agent.

## Output discipline

- Cite with `file:line`.
- For misconfiguration findings, include a before/after config snippet.
- Short summary to orchestrator.