---
description: .NET-specific detection rules and idioms for the security-review pipeline. Auto-attaches when a security-review agent opens C#/F#/VB source or .NET project and config files.
applyTo: "**/{*.cs,*.fs,*.vb,*.cshtml,*.razor,*.vbhtml,*.xaml,*.csproj,*.fsproj,*.vbproj,*.sln,*.props,*.targets,web.config,app.config,appsettings.json,appsettings.*.json,global.json,Directory.Packages.props,packages.lock.json,packages.config}"
---

# .NET Security Review — Instructions

When reviewing .NET code, apply these extra detection rules on top of the subagent's base logic.

## Framework fingerprints (for `tech-stack.md`)

- ASP.NET Core: `Microsoft.AspNetCore.App` framework reference, `builder.Build()` in `Program.cs`, minimal APIs via `app.MapGet/Post/...`, controllers via `[ApiController]`.
- ASP.NET MVC / Web API (legacy .NET Framework): `System.Web.Mvc`, `System.Web.Http`, `Global.asax`.
- WCF: `System.ServiceModel`, `[ServiceContract]`, `[OperationContract]`.
- Azure Functions: `[FunctionName]` or `[Function]`, `host.json`.
- gRPC: `AddGrpc()`, `[GrpcService]`.
- SignalR: `MapHub<>`.
- Blazor Server / WebAssembly: `App.razor`, `_Host.cshtml`, `BlazorWebAssemblyApp`.
- Service Fabric, Orleans, Akka.NET are legitimate but less common — note if present.
- NancyFX (legacy): `NancyModule`.

## Endpoint discovery cues

HTTP:
- `[Route]`, `[HttpGet]`, `[HttpPost]`, `[HttpPut]`, `[HttpDelete]`, `[HttpPatch]`, `[FromQuery]`, `[FromBody]`, `[FromRoute]`, `[FromForm]`, `[FromHeader]`, `[FromServices]`.
- Minimal APIs: `app.MapGet(path, handler)`, `app.MapPost(...)`, `RouteGroupBuilder`.
- WebApi (legacy): `ApiController` base class.

Messaging / eventing:
- `[ServiceBusTrigger]`, `[EventGridTrigger]`, `[EventHubTrigger]`, `[QueueTrigger]`, `[BlobTrigger]`, `[CosmosDBTrigger]`.
- `IHostedService` / `BackgroundService` for long-running jobs.
- MassTransit consumers: `IConsumer<T>`.
- NServiceBus handlers: `IHandleMessages<T>`.

WCF:
- `[OperationContract]` on a `[ServiceContract]`-decorated interface; service host configuration in `web.config`/`app.config`.

## Injection deep-dive — .NET specifics

### Command Injection
- `System.Diagnostics.Process.Start` with a single string argument invokes a shell on some OSes; with `ProcessStartInfo` + `UseShellExecute=true` the OS parses the string.
- Concatenating into `ProcessStartInfo.Arguments` is always unsafe; prefer `ProcessStartInfo.ArgumentList.Add(each)` (available net5+). Escaping rules on Windows differ from POSIX — flag any handwritten quoting.
- `System.Management.Automation.PowerShell.Create().AddScript(userInput)` → RCE.
- Roslyn `CSharpScript.EvaluateAsync(userCode)` → RCE.
- DLR `dynamic` + `ExpandoObject` deserialized from user input used as code dispatch.
- `Assembly.Load`/`Assembly.LoadFrom` with user-controlled bytes/paths.

### Path Traversal
- `Path.Combine(root, userInput)` is **not** a safety function — it happily returns outside `root` if `userInput` is rooted or contains `..`.
- Right pattern: `var full = Path.GetFullPath(Path.Combine(root, userInput)); if (!full.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw;`.
- `StaticFileMiddleware` with a custom `IFileProvider` that composes paths from user input.
- `ZipArchive.ExtractToDirectory(path, entryName)` and equivalent handrolled extraction — zip-slip.
- Razor `~/Views/` resolution with user-controlled view name.
- `Server.MapPath(userInput)` (legacy).

### SQL Injection
- ADO.NET: `SqlCommand.CommandText = $"SELECT ... {userInput}"`. Use `SqlParameter`.
- EF Core: `FromSqlRaw($"... {userInput}")` vs `FromSqlInterpolated($"... {userInput}")`. The latter **is** parameterized by EF — check which overload is actually called.
- Dapper: `conn.Query(query, new { id })` is fine; `conn.Query($"... {id}")` is not.
- Stored-proc invocation with concatenated parameters — still unsafe.
- `SqlParameter` with `DbType.String` and user-controlled `Value` is fine, but dynamic column/table names bypass parameterization — treat ORDER BY / column selection specially.

### NoSQL Injection
- MongoDB.Driver: `BsonDocument.Parse(userJson)` then passing to `.Find(...)` — operator injection.
- `FilterDefinition<T>.AsBson()` built from untrusted JSON.
- Cosmos DB SQL queries with string interpolation: `$"SELECT * FROM c WHERE c.id = '{id}'"`. Use parameterized `QueryDefinition.WithParameter`.
- Redis `EVAL` with user-concatenated Lua.
- Elasticsearch (`NEST`): `WrapperQuery(json)` with user-controlled JSON.

## XXE — .NET specifics

- `XmlDocument`: set `XmlResolver = null` (default changed in .NET 4.5.2+, but legacy code still unsafe).
- `XmlReader`: use `XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null }`.
- `XmlTextReader` is unsafe by default in .NET Framework; prefer `XmlReader.Create(...)`.
- `XslCompiledTransform.Load` with `XsltSettings.EnableScript` + `DocumentFunction` is RCE territory.
- WCF: `DataContractSerializer` is safer than `NetDataContractSerializer`; the latter is a known insecure deserialization sink.

## XSS — .NET specifics

- Razor: `@Html.Raw(userInput)` and `IHtmlContent` values built from user input.
- `HtmlString` wrapping unescaped user data.
- MVC `Html.Encode` being manually skipped with `@{ }` blocks writing directly.
- Blazor Server: `MarkupString(userInput)` in a component.
- ASP.NET Web Forms `<%= %>` (not `<%: %>`).
- JS-side: in Razor pages that render inline scripts, `@Json.Serialize(model)` is safer than `@Html.Raw(JsonConvert.SerializeObject(model))` which breaks CSP if allow-listed.

## SSRF — .NET specifics

- `HttpClient` allow-lists should live in a `DelegatingHandler` that rejects before `SendAsync`.
- `HttpClientHandler.ServerCertificateCustomValidationCallback` returning `true` is a finding.
- `HttpClient.AllowAutoRedirect = true` (default) combined with user-controlled URL enables redirect-based SSRF bypass.
- `WebClient` (legacy) — flag its use as deprecated.
- Azure cloud metadata endpoint is `169.254.169.254`; GCP is `metadata.google.internal`; AWS is `169.254.169.254` — allow-list must block IMDS unless explicitly needed and IMDSv2 is enforced.

## Security misconfiguration — .NET specifics

- `app.UseDeveloperExceptionPage()` reachable when `env.IsDevelopment()` is false — rare but check.
- Antiforgery: `services.AddControllersWithViews(options => options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute()))` missing.
- Data protection keys: `AddDataProtection().PersistKeysToFileSystem(...)` without `ProtectKeysWith...`.
- `Authorize` attribute missing globally — check `AuthorizationPolicy`/`FallbackPolicy` wiring.
- JWT validation: `TokenValidationParameters.ValidateIssuer / ValidateAudience / ValidateLifetime / ValidateIssuerSigningKey` all set to `true`; `ValidateIssuerSigningKey=false` is catastrophic.
- Cookies: `HttpOnly`, `Secure`, `SameSite` on `CookieAuthenticationOptions` and `AntiforgeryOptions`.
- CORS: `AllowAnyOrigin()` + `AllowCredentials()` — not allowed by the CORS spec and ASP.NET will throw, but some code paths set permissive policies at runtime.
- Identity: password options `RequiredLength < 8`, `RequireNonAlphanumeric=false` + no additional constraints.
- Hashing: `Rfc2898DeriveBytes` iterations `< 100_000` for passwords; prefer `PasswordHasher<>` with default v3 params.
- Deserialization: `BinaryFormatter`, `NetDataContractSerializer`, `SoapFormatter`, `LosFormatter` — all high-risk.
- `appsettings.json` with hardcoded connection strings containing `Password=` in source.
- `global.json` pinning to unsupported SDK.

## Language-aware fix templates

Prefer modern C#:
- `System.Text.Json` over `Newtonsoft.Json` for new code (and call out `TypeNameHandling.All` if found in old code — deserialization RCE).
- `Span<byte>` for crypto buffers.
- `RandomNumberGenerator.Create()` for tokens; never `Random` for secrets.
- `Convert.ToHexString`/`FromHexString` / `Base64Url` APIs for encoding.