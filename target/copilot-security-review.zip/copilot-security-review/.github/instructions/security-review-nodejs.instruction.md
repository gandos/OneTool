---
description: Node.js / JavaScript / TypeScript-specific detection rules and idioms for the security-review pipeline. Auto-attaches when a security-review agent opens JS/TS source, package manifests, or Node config files.
applyTo: "**/{*.js,*.mjs,*.cjs,*.jsx,*.ts,*.mts,*.cts,*.tsx,package.json,package-lock.json,pnpm-lock.yaml,yarn.lock,tsconfig.json,tsconfig.*.json,.nvmrc,.node-version,next.config.js,next.config.mjs,next.config.ts,nest-cli.json}"
---

# Node.js Security Review — Instructions

When reviewing Node.js / JavaScript / TypeScript code, apply these extra detection rules on top of the subagent's base logic.

## Framework fingerprints (for `tech-stack.md`)

- Express: `import express` / `require('express')`, `express()` call, `app.use`.
- Fastify: `fastify()`, schema-based route registration, `fastify.register(...)`.
- NestJS: `@Module`, `@Controller`, `@Injectable`, `main.ts` bootstrapping.
- Koa: `new Koa()`, `app.use(ctx => ...)`.
- Hapi: `Hapi.server`, `server.route`.
- GraphQL: Apollo Server, `@nestjs/graphql`, `graphql-yoga`, `express-graphql`.
- Next.js: `pages/api/*`, `app/**/route.{ts,js}`, `getServerSideProps`, Server Actions.
- Remix / SvelteKit / Nuxt server routes.
- AWS Lambda: `exports.handler`, `export const handler`, `@aws-lambda-powertools/*`.
- Azure Functions (JS/TS): `index.js` with `module.exports = async function (context, req)`.

## Endpoint discovery cues

Routers:
- Express: `app.get/post/put/delete/patch/all/use`, `router.<method>`.
- Fastify: `fastify.get/post/...`, `fastify.route({ method, url, handler })`, `app.register(routes, { prefix })`.
- Koa: `router.get/post/...` via `@koa/router`.
- NestJS: `@Get`, `@Post`, `@Put`, `@Delete`, `@Patch`, `@All`, `@Param`, `@Query`, `@Body`, `@Headers`, `@Req`, `@Res`, `@UploadedFile`.
- Next.js App Router: `export async function GET(request)` in `route.ts`.

GraphQL resolvers — every `Query` / `Mutation` / `Subscription` field is an endpoint.

Workers / consumers:
- `bullmq` `new Worker(queueName, job => ...)`.
- `kafkajs` `consumer.run({ eachMessage })`.
- `amqplib` `channel.consume(queue, msg => ...)`.
- `@aws-sdk/client-sqs` `ReceiveMessageCommand`.

## Injection deep-dive — Node specifics

### Command Injection
- `child_process.exec(userInput)` — always spawns a shell. Unsafe with user input.
- `child_process.execSync(userInput)` — same.
- `spawn(cmd, args, { shell: true })` — the `shell:true` turns array-form back into string-form.
- `execFile(file, args)` — safer than `exec`, but still unsafe if `file` is user-controlled or if the file itself interprets argv as a script (e.g. `bash`, `python`, `node -e`).
- `eval(userInput)` — RCE.
- `vm.runInNewContext(userCode)` / `vm.runInThisContext(userCode)` — not a sandbox. Still RCE.
- `new Function(userCode)` / `Function(...args, userBody)` — RCE.
- `require(userString)` — load-arbitrary-module, often reachable via NPM dependency confusion.
- Template engines that allow JS execution: `pug` with `!= expr` where `expr` is eval'd; `EJS` `<%- %>` paired with server-side code; Handlebars helpers calling `eval`.

### Path Traversal
- `fs.readFile(userPath, ...)` without validation.
- `fs.createReadStream(path.resolve(root, userPath))` without `startsWith(root + path.sep)` check.
- `res.sendFile(userPath)` — Express resolves relative to root if you provide one; if you pass `userPath` containing `..` and no root, traversal is trivial.
- `res.download(userPath)` — same.
- `express.static(root)` with a custom middleware that modifies `req.url` to include user input.
- Archive extraction: `tar` package `filter` option; `adm-zip` `extractAllTo`; `unzipper` `Parse()` iterating entries. Always validate `path.resolve(outputDir, entry.fileName).startsWith(outputDir + path.sep)`.
- Prototype-pollution-adjacent: `lodash.set(obj, userKey, value)` → not path traversal per se but call out adjacent `__proto__`/`constructor.prototype` sinks.

### SQL Injection
- `mysql`/`mysql2`: `connection.query('SELECT ... ' + userInput)` — unsafe. Use `connection.query('SELECT ... ?', [userInput])` or `connection.execute(...)`.
- `pg` (node-postgres): `client.query('SELECT ... ' + userInput)` — unsafe. Use `client.query('SELECT ... $1', [userInput])`.
- `sqlite3`: `db.run(query)` with concatenation.
- Sequelize: `sequelize.query(sql, { replacements })` vs `sequelize.query(sql)` with interpolation in the SQL string.
- Knex: `knex.raw('... ' + userInput)`; prefer `knex.raw('... ?', [userInput])` or the query builder's parameterized methods.
- TypeORM: `repository.query('... ' + userInput)` vs `repository.query('... $1', [userInput])`; `createQueryBuilder().where('x = ' + userInput)` unsafe — use `.where('x = :x', { x: userInput })`.
- Prisma: generally safe (parameterized by design) **except** `$queryRawUnsafe(userInput)`; `$queryRaw` is a tagged template and safe.

### NoSQL Injection
- MongoDB driver: `collection.find(req.body)` passes user-controlled operators. Strip `$`-prefixed keys or use `express-mongo-sanitize`.
- Operator-injection login bypass: `User.findOne({ user: req.body.user, pass: req.body.pass })` where `req.body.pass = {$ne: null}`.
- `$where` with user-controlled strings → server-side JS execution.
- Mongoose schema-free `Schema.Types.Mixed` fields propagated from request body.
- Redis `EVAL` with user-concatenated Lua, `Redis.createClient().eval(script, ...)`.

## XXE — Node specifics

Most JSON-first Node apps don't parse XML; verify before flagging.

- `libxmljs`: `parseXml(xml, { noent: true, dtdload: true, dtdvalid: true })` → unsafe.
- `xml2js`: relatively safe defaults; still check `strict:false` + external references.
- `fast-xml-parser`: `processEntities:true` with a custom map that includes externally-referenced entities.
- `@xmldom/xmldom`: versions have had DOCTYPE issues; rely on SCA to flag outdated versions.
- SOAP libraries: `soap` npm package delegates to `sax-js` / `xmldom`.
- SVG rendering via `svg.js`, SVGO, or image libraries — SVG can carry XXE via embedded DTD.

## XSS — Node specifics

- Express `res.send(\`<html>${userInput}</html>\`)` — unsafe.
- Template engines:
  - Pug: `= foo` escapes; `!= foo` does not.
  - EJS: `<%= foo %>` escapes; `<%- foo %>` does not.
  - Handlebars: `{{ foo }}` escapes; `{{{ foo }}}` does not. Custom helpers calling `new Handlebars.SafeString(userInput)` are unsafe.
  - Nunjucks: autoescape must be on; `{{ foo | safe }}` is unsafe.
- React: `dangerouslySetInnerHTML={{ __html: userInput }}` — unsafe. `href={userUrl}` can render `javascript:` URIs — sanitize scheme.
- Next.js: Server Components rendering user HTML via `<div dangerouslySetInnerHTML>`.
- Markdown rendering: `marked(userInput)` pre-2.0 allowed HTML passthrough; confirm `sanitize` / DOMPurify step.
- DOMPurify with `ALLOWED_URI_REGEXP` weakened → bypass.

## SSRF — Node specifics

- `fetch`, `axios`, `got`, `undici`, `node-fetch`, `request` (deprecated), `superagent`.
- `http.get(userUrl)` / `https.get(userUrl)`.
- Redirect handling: `axios` by default follows 5 redirects; `got` follows by default. Any SSRF allow-list must be re-applied after each redirect, or redirects must be disabled.
- DNS rebinding: validation at URL-parse time doesn't prevent the second DNS resolution the HTTP client makes. Fix: resolve hostname once, pin the connection to the resolved IP, then validate the IP against deny-lists.
- `puppeteer.goto(userUrl)` is SSRF with a real browser — don't forget to deny-list loopback/metadata there too.
- Webhook handlers that perform outbound calls to `req.body.callbackUrl` are a classic SSRF foothold.

## Security misconfiguration — Node specifics

- Express: no `helmet()`, or Helmet configured with `contentSecurityPolicy: false`.
- CORS: `cors()` with no options → `*`; `cors({ origin: true })` reflects the Origin header; combined with credentials → broken.
- Trust proxy: `app.set('trust proxy', true)` while behind an untrusted edge; X-Forwarded-For spoofing.
- Rate limiting absent on authentication endpoints.
- Session: `express-session` with `secret: 'keyboard cat'` / hardcoded, `cookie: { secure: false, httpOnly: false, sameSite: 'none' }` in prod.
- JWT: `jsonwebtoken` `verify(token, secret, { algorithms: ['none'] })` — never allow `none`.
- JWT: decode without verify (`jwt.decode` vs `jwt.verify`) used to drive authorization — flag.
- `NODE_TLS_REJECT_UNAUTHORIZED=0` set anywhere — flag.
- `https.Agent({ rejectUnauthorized: false })` — flag.
- `crypto.createCipher` (deprecated insecure) vs `createCipheriv`.
- `crypto.randomBytes` for tokens; flag `Math.random()` for secrets / session ids.
- Prototype-pollution sinks: `lodash.merge`, `lodash.defaultsDeep`, `merge-deep`, `object-path`, `set-value` called with user JSON.
- Deserialization: `node-serialize.unserialize(userInput)` (RCE), `serialize-javascript` with user input, YAML `yaml.load(userInput)` (unsafe) vs `yaml.safeLoad` / `yaml.load(input, 'core')` in newer versions.
- File upload: `multer` without `limits` and `fileFilter`; `formidable` without `maxFileSize`.
- Environment leakage: `process.env` serialized into responses; `console.log(process.env)` in request paths.
- Package.json: `"scripts": { "postinstall": "curl ... | sh" }` — supply chain red flag.
- Lockfile absent: `package-lock.json` / `pnpm-lock.yaml` missing in a repo — flag.

## Language-aware fix templates

- Prefer `zod` / `valibot` / `joi` / `class-validator` at the edge; TypeScript types are not runtime validation.
- Prefer `execa` with array-form over `child_process.exec`.
- Prefer `node:fs/promises` over callback-style for reviews (easier to read).
- Prefer structured logging (`pino`, `winston`) over `console.log` and always redact known secret keys.