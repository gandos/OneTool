---
description: Java-specific detection rules and idioms for the security-review pipeline. Auto-attaches whenever a security-review agent opens Java source or Maven/Gradle build files.
applyTo: "**/{*.java,*.kt,*.kts,*.groovy,*.gradle,*.jsp,*.jspx,pom.xml,build.gradle,build.gradle.kts,settings.gradle,settings.gradle.kts,gradle.properties,application.yml,application.yaml,application.properties,application-*.yml,application-*.yaml,application-*.properties,bootstrap.yml,bootstrap.yaml,bootstrap.properties,bootstrap-*.yml,bootstrap-*.yaml,bootstrap-*.properties}"
---

# Java / JVM Security Review — Instructions

When reviewing JVM code (Java, Kotlin, Groovy), apply these extra detection rules on top of the subagent's base logic.

## Framework fingerprints (for `tech-stack.md`)

- Spring ecosystem: `org.springframework.boot:spring-boot-starter-*`, `@SpringBootApplication`, `@EnableWebSecurity`.
- Jakarta EE / Java EE: `javax.ws.rs.*` or `jakarta.ws.rs.*`, `javax.ejb.*`, `javax.servlet.*`.
- Quarkus: `@QuarkusMain`, `io.quarkus:quarkus-*`.
- Micronaut: `io.micronaut:micronaut-*`, `@Controller` from `io.micronaut.http.annotation`.
- Play: `play.api.mvc.*`.
- Struts: `org.apache.struts2.*` — **flag immediately** given the historical CVE tail.
- Vert.x: `io.vertx.*`.
- Dropwizard: `io.dropwizard.*`.

## Endpoint discovery cues

HTTP annotations:
- `@RestController`, `@Controller`, `@RequestMapping`, `@GetMapping`, `@PostMapping`, `@PutMapping`, `@DeleteMapping`, `@PatchMapping`, `@RequestParam`, `@PathVariable`, `@RequestBody`, `@ModelAttribute`, `@RequestHeader`, `@CookieValue`.
- JAX-RS: `@Path`, `@GET`, `@POST`, `@PUT`, `@DELETE`, `@FormParam`, `@QueryParam`, `@PathParam`, `@HeaderParam`, `@CookieParam`, `@BeanParam`.
- WebFlux functional: `RouterFunctions.route(...).GET(...)`.
- Raw: `HttpServlet.doGet/doPost/doPut/doDelete/service`, `Filter.doFilter`.

Messaging:
- `@KafkaListener`, `@JmsListener`, `@RabbitListener`, `@StreamListener`, `@SqsListener`, `@EventListener`.

Scheduled:
- `@Scheduled`, Quartz `Job.execute`.

SOAP:
- `@WebService`, `@WebMethod`, Apache CXF `@POST @Path` style, Axis generated skeletons.

## Injection deep-dive — Java specifics

### Command Injection
- **Check for `ProcessBuilder` safety**: array-form is safer; shell-form (`bash -c <string>`) is never safe with concatenation.
- Watch for `ScriptEngineManager().getEngineByName("nashorn"|"js"|"groovy"|"rhino")` + `.eval(userInput)` — remote code execution.
- Watch for Groovy's `Eval.me`, `GroovyShell().evaluate(...)`, `Binding` with user-controlled names.
- SpEL expressions: `new SpelExpressionParser().parseExpression(userInput).getValue(...)` is RCE. Spring `@Value("#{...}")` with user-controlled keys is rare but possible.
- Apache Commons JXPath `JXPathContext.getValue(userXPath)` — path expression injection.
- OGNL (legacy Struts): `Ognl.getValue(userExpr, ...)`.

### Path Traversal
- `File`, `Paths.get`, `FileSystems.getDefault().getPath(...)`: normalize via `toRealPath()` or `getCanonicalFile()`, then check `startsWith(allowedRoot)`.
- Archive extraction (zip-slip): `ZipEntry.getName()` must be validated — `Files.createDirectories(outputDir.resolve(entry.getName()).normalize())` alone is not enough; prefix-check after resolution.
- Servlet `getResource` / `getResourceAsStream` with user-controlled suffix.
- Spring `Resource` / `ResourceLoader.getResource(userPath)`.
- Thymeleaf template name from user input: `TemplateEngine.process(userTemplateName, ...)` — not just XSS, also SSTI / file-disclosure.

### SQL Injection
- **JPA / Hibernate**: `entityManager.createQuery("... " + userInput)`, `@NamedQuery(name="x", query="...")` with dynamic appends.
- `@Query(value="... ORDER BY " + #sort, nativeQuery=true)` — Spring Data — `ORDER BY` is almost never parameterized.
- MyBatis: `${param}` (interpolated) vs `#{param}` (parameterized). `${}` is unsafe.
- jOOQ: `DSL.sql("...", bindValues)` vs raw `DSL.sql(concatenatedString)`.
- `JdbcTemplate.queryForObject(String sql, Class<?> requiredType)` where sql was concatenated — still unsafe even though JdbcTemplate is "safe".

### NoSQL Injection
- Spring Data MongoDB: `@Query("{ 'user' : ?0 }")` is safe; `@Query("{ 'user' : '" + #user + "' }")` is not.
- `Document.parse(userJson)` produces untrusted BSON.
- `MongoTemplate.find(new BasicQuery(userJsonString))`.

## XXE — Java specifics

Lock down every XML parser with these features:
```java
dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
dbf.setXIncludeAware(false);
dbf.setExpandEntityReferences(false);
```
Flag any XML parser constructed **without** the equivalent settings. Check SOAP endpoints (CXF, Axis2) for their stack-level hardening.

## XSS — Java specifics

- Thymeleaf: `th:utext` always unsafe with untrusted input.
- JSP: `<%= %>` and `<c:out value="..." escapeXml="false" />` unsafe.
- FreeMarker: autoescaping must be on; `<#noautoesc>` blocks unsafe.
- Velocity: escape tool must be wired; raw `$userInput` unsafe.
- Spring MVC returning `String` with `produces=MediaType.TEXT_HTML_VALUE` built by concatenation.

## SSRF — Java specifics

- `URL.openConnection` / `URLConnection` inherit default redirect follow. `HttpURLConnection.setInstanceFollowRedirects(false)` is required as part of SSRF defense-in-depth.
- `RestTemplate` / `WebClient`: the builder's `uriBuilderFactory` does not perform allow-listing. Always validate the scheme + host before the call.
- Apache HttpClient: custom `HttpRoutePlanner` is the right place for allow-listing.
- ImageIO: `ImageIO.read(new URL(userUrl))` fetches remote images server-side — SSRF sink.

## Security misconfiguration — Java specifics

- Spring Security: any `http.csrf().disable()` needs a written justification in code comments; flag if none.
- `http.authorizeHttpRequests().anyRequest().permitAll()` with a reachable handler returning sensitive data.
- `@CrossOrigin` with no arguments allows all origins — flag.
- Actuator endpoints: `management.endpoints.web.exposure.include=*` without Spring Security rules covering `/actuator/**`.
- Jackson polymorphic deserialization with `enableDefaultTyping` or `@JsonTypeInfo(use=Id.CLASS)` + user input → RCE pattern. Flag.
- Deserialization: `ObjectInputStream.readObject` on any socket / HTTP payload.
- Logging frameworks: Log4j `< 2.17.1` (Log4Shell), Logback `JNDI` lookups if enabled.
- Default admin credentials in `application.properties` (`spring.security.user.password=...`).
- `trustAllCerts` TrustManager or `HostnameVerifier` that returns `true` unconditionally.
- `SecureRandom` NOT used for tokens; `Math.random()` or `new Random()` for secrets is a finding.

## Language-aware fix templates

For every finding, the fix snippet should prefer Java 17+ idioms if the project's JDK is 17+:
- Pattern matching for `instanceof` in validators.
- `HexFormat`/`Base64.getUrlEncoder().withoutPadding()` for tokens.
- `java.net.http.HttpClient` with a custom `HttpClient.Redirect.NEVER` + hostname validator for SSRF-safe calls.