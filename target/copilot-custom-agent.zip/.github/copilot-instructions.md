# Project-wide Copilot instructions — security-review pipeline

These are minimal, always-on instructions. Most security-review guidance lives in the custom agents under `.github/agents/` and the language-specific instruction files under `.github/instructions/`. Do not duplicate that guidance here.

## General rules (all agents, all modes)

- This repository runs a security-review pipeline. Whenever a security-review custom agent is the active agent, produce only artifact files under `.security-review/` (never paste full findings into chat).
- **Artifact format is HTML** with interconnected hyperlinks — clicking any endpoint ID, vulnerability finding ID, dependency ID, datastore ID, external-service ID, or data-flow block ID navigates to its detail. Follow the "HTML output convention" in `.github/agents/security-review.agent.md` (page skeleton, ID/anchor schemes, link rules, code-block escaping). Plain-text mention of an `EP-` / `DF-` / `DS-` / `EXT-` / `DEP-` / `VULN-` token without a wrapping `<a href>` is a contract violation.
- Cite every security claim with `<code>file:line-range</code>`. Evidence > opinion. (Source-file citations stay as plain `<code>` text — they point at user source, not artifacts.)
- Redact live secrets before writing them to any artifact. Keep the first 3 characters as fingerprint; replace the rest with `***`.
- Prefer existing sanitizers/validators from the project's frameworks over handrolled regex.
- Do **not** run destructive shell commands (no `rm -rf`, no `git reset --hard`, no writes outside `.security-review/`) unless the user explicitly authorizes it.
- If a step's expected inputs (e.g. recon artifacts) are missing, stop and surface the gap rather than silently re-running earlier steps or full-repo scans.
- HTML-escape every `<pre><code>` block (Evidence, Exploit Payload, Fix before/after, sample HTTP requests/responses). Reserved characters: `&` `<` `>` `"` `'`.