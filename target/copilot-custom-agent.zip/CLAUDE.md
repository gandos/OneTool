# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this project is

A reusable **GitHub Copilot custom-agent pipeline** for application security reviews. It is a bundle of Markdown configuration files — not a buildable application. The files are meant to be copied into any Java, .NET, or Node.js target repository so that VS Code's Copilot Chat can orchestrate a structured security review.

**Requirements in the target repository:**
- VS Code 1.106+
- GitHub Copilot Chat for VS Code 0.33.3+
- GitHub Copilot for VS Code 1.388+
- GitHub Copilot Business/Enterprise with custom agents policy enabled

**Installation:** Copy the `.github/` directory into the root of the target repository. VS Code auto-discovers agents and instructions — no build step.

**Invocation:** In Copilot Chat, select the **Security Review Orchestrator** agent and type: `Run a full security review on this repository.`

## Architecture

The pipeline follows a **sequential orchestrator → specialist subagents** pattern where every step persists its output to disk (under `.security-review/`) so that later steps read artifacts rather than chat history.

### Agent files (`.github/agents/`)

| File | Role |
|---|---|
| `security-review.agent.md` | **Orchestrator** — never analyzes code; only coordinates the pipeline and stitches the final report |
| `security-recon.agent.md` | Step 1: maps tech stack, all endpoints, data-flow traces, datastores, external integrations |
| `security-vuln-injection.agent.md` | Step 2a: command/path/SQL/NoSQL injection |
| `security-vuln-common.agent.md` | Step 2b: XXE, XSS, SSRF, security misconfiguration |
| `security-vuln-bizlogic.agent.md` | Step 2c: auth bypass, MFA bypass, transaction logic, IDOR/mass-assignment |
| `security-vuln-sca.agent.md` | Step 2d: dependency inventory and known-vulnerable version detection |

### Instruction files (`.github/instructions/`)

Auto-attached by file-glob matching in the target repo. Each file adds language-specific detection patterns to every subagent:

- `security-review-java.instruction.md` — Spring Security, JAX-RS, JPA/Hibernate, MyBatis, Struts
- `security-review-dotnet.instruction.md` — ASP.NET Core, Minimal APIs, WCF, Azure Functions, EF Core
- `security-review-nodejs.instruction.md` — Express, Fastify, NestJS, Next.js, Lambda, React DOM sinks

### Output directory (`.security-review/`)

Written inside the **target** repository, not this one. **All artifacts are HTML files** with cross-page hyperlinks — clicking an endpoint ID, finding ID, dep ID, datastore ID, external-service ID, or data-flow block ID navigates to its detail. A shared stylesheet (`assets/style.css`) is written once by the orchestrator's Step 0. ID/anchor conventions and the page skeleton are defined under "HTML output convention" in [security-review.agent.md](.github/agents/security-review.agent.md).

```text
.security-review/
├── assets/style.css
├── 00-meta/{scope.html, run-log.html}
├── 01-reconnaissance/{tech-stack, endpoints, data-flow, datastores, external-services, INDEX}.html
├── 02-vulnerabilities/
│   ├── deep-dive/{command-injection, path-traversal, sql-injection, nosql-injection}.html
│   ├── common/{xxe, xss, ssrf, security-misconfiguration}.html
│   ├── bizlogic/{auth-bypass, mfa-bypass, transaction-logic, business-logic}.html
│   └── sca/components.html
└── final-report.html
```

Anchor schemes: `EP-NNN` (endpoint), `DF-EP-NNN-<sink>-<n>` (data-flow block), `DS-NNN`/`EXT-NNN` (datastore/external-service), `DEP-<ecosystem>-<name>` (dependency), `VULN-<CLASS>-NNN` (finding — `SQLI`, `EL`, `CMDI`, `PATH`, `NOSQLI`, `XXE`, `XSS`, `SSRF`, `MISCONF`, `AUTHBYPASS`, `MFA`, `TXN`, `BIZ`, `SCA`).

## Key rules (from `.github/copilot-instructions.md`)

These apply whenever editing agent or instruction files:

- Agents write findings **only** to `.security-review/` — never paste full findings into chat.
- Every security claim must cite `file:line-range`.
- Redact live secrets before writing to any artifact (keep first 3 chars as fingerprint, replace the rest with `***`).
- Prefer framework-provided sanitizers/validators over handrolled regex in fix examples.
- Do not include destructive shell commands (`rm -rf`, `git reset --hard`, writes outside `.security-review/`) unless the user explicitly authorizes it.
- If a step's expected inputs are missing, surface the gap rather than silently re-running earlier steps.

## Finding schema

Every vulnerability finding across all subagents must include: severity (Critical/High/Medium/Low/Info), OWASP class, CWE, confidence + rationale, `file:line-range`, source→sink data-flow trace, evidence (actual code), root cause label, validator-chain analysis with bypass proof, concrete exploit payload, second-order injection check, exploitability pre-conditions, before/after fix code, and CVE/framework references.

## Customization points

- **Change output directory:** Edit the `path:` setting in `security-review.agent.md` (single location; search-replace the rest).
- **Add a language:** Create `.github/instructions/security-review-<lang>.instructions.md` with an `applyTo` glob.
- **Remove a vulnerability class:** Delete the subagent file and remove its step from the orchestrator's pipeline section.
- **Enable shell audit tools:** Uncomment the `runCommands` tool in `security-vuln-sca.agent.md`.

## VS Code 1.106 known limitations

- Subagents cannot invoke other subagents (supported in 1.110+); all Step 2 agents run directly under the orchestrator.
- Parallel subagent execution is not available (1.107+); steps run sequentially.
- `applyTo` globs with comma-separated patterns are unreliable; agents explicitly reference instruction files instead.
- Run-log failures are non-fatal; the pipeline continues with in-memory buffering.
