# Copilot Security Review Agents — Setup & Usage

## ⚠️ VS Code Version Requirement

`runSubagent` requires **VS Code ≥ 1.107** and **GitHub Copilot Chat ≥ 1.388**.
You are on VS Code 1.106 — please update first:
`Help → Check for Updates`

You also need to enable the feature flag:

```json
// .vscode/settings.json
{
  "chat.customAgentInSubagent.enabled": true
}
```

---

## File Structure

Copy the three `.agent.md` files into your workspace like this:

```
your-project/
├── .github/
│   └── copilot/
│       └── agents/
│           ├── security-orchestrator.agent.md
│           ├── security-recon.agent.md
│           └── owasp-analyzer.agent.md
├── .vscode/
│   └── settings.json          ← add the feature flag here
└── src/                       ← your application source code
```

> **Tip:** VS Code also supports `.vscode/agents/` as an agent location
> if you prefer not to use `.github/`.

---

## How to Run

1. Open Copilot Chat (`Ctrl+Shift+I` / `Cmd+Shift+I`)
2. Switch to **Agent mode** using the mode dropdown
3. Select the **SecurityOrchestrator** agent from the agent picker
4. Type:

   ```
   Run a full security review of this workspace.
   ```

5. Approve any file-read or tool-use confirmations Copilot presents.

The orchestrator will:
1. Create `security-review/`
2. Launch **SecurityRecon** → writes `security-review/recon-report.md`
3. Launch **OWASPAnalyzer** → writes `security-review/owasp-report.md`
4. Write `security-review/executive-summary.md`
5. Report the severity breakdown back to you in chat

---

## Output Files

| File | Contents |
|---|---|
| `security-review/recon-report.md` | Tech stack, endpoint map, auth mechanisms, dependencies, config scan |
| `security-review/owasp-report.md` | Full OWASP Top 10 findings with file/line citations and remediations |
| `security-review/executive-summary.md` | Risk table, top 5 findings, immediate actions |

---

## Running Subagents Individually

You can invoke either subagent directly for a focused scan:

**Recon only:**
In Copilot Chat → select **SecurityRecon** agent → type:
```
Perform reconnaissance on the workspace and write results to security-review/recon-report.md
```

**OWASP analysis only** (requires a completed recon report):
In Copilot Chat → select **OWASPAnalyzer** agent → type:
```
Analyse the codebase for OWASP Top 10 vulnerabilities using security-review/recon-report.md as context.
```

---

## Supported Stacks

| Language | Frameworks detected |
|---|---|
| Java | Spring Boot, Spring MVC, JAX-RS, Micronaut, Quarkus |
| .NET | ASP.NET Core, Web API, Minimal API, Blazor |
| Node.js | Express, Fastify, NestJS, Koa, Hapi |

---

## Notes & Limitations

- All agents are **read-only** — they never modify your source files.
- Findings are AI-generated and must be reviewed by a human security engineer
  before acting on them.
- For large codebases (> ~500 files), consider scoping the review by pointing
  the orchestrator at a subdirectory.
- The agents do not perform network scanning or runtime DAST — this is pure
  static analysis.
